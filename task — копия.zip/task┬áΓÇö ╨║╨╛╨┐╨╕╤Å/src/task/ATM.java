package task;
import java.util.Scanner;

public class ATM {
    private float moneyATM;

    public ATM(float moneyATM){
        this.moneyATM = moneyATM;
    }

    public float getMoneyATM() {
        return moneyATM;
    }

    public void setMoneyATM(float moneyATM) {
        this.moneyATM = moneyATM;
    }

    public void upBalance(bankAccount account,Client client) {
        float balance = account.getBalance();
        float clientsMoney = client.getClientsMoney();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Какую сумму хотите добавить на счет?:");
        float amount = scanner.nextFloat();
        if(clientsMoney >= amount && amount<=1000){
            account.setBalance(balance + amount);
            moneyATM += amount;
            System.out.println("Средства успешно добавлены!");
        }
        else if(amount>=1000){
            System.out.println("Сумма пополнения не может быть выше 1000 руб !");
        }
        else if (amount > clientsMoney){
            System.out.println("У вас недостаточно средств");
        }

        client.setClientsMoney(clientsMoney - amount);

    }

    public void lowBalance(bankAccount account,Client client) {
        float balance = account.getBalance();
        float clientsMoney = client.getClientsMoney();

        Scanner scanner = new Scanner(System.in);
        System.out.println("Какую сумму хотите снять со счета?:");
        float amount = scanner.nextFloat();
        if(balance >= amount && moneyATM >= amount){
            account.setBalance(balance - amount);
            moneyATM -= amount;
            System.out.println("Средства успешно сняты!");
        }
        else if(amount >= balance){
            System.out.println("На балансе недостаточно средств!");
        }
        else if(amount > moneyATM){
            System.out.println("В банкомате недостаточно средств!");
        }

        client.setClientsMoney(clientsMoney + amount);

    }
}