package task;
import java.util.Scanner;
public class Client {

    public float clientsMoney;

    public Client(float clientsMoney) {
        this.clientsMoney = clientsMoney;
    }

    public float getClientsMoney() {
        return clientsMoney;
    }

    public void setClientsMoney(float clientsMoney) {
        this.clientsMoney = clientsMoney;
    }
}
