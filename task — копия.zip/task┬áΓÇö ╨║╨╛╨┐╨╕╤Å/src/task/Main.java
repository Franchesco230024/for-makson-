package task;

import java.util.Objects;
import java.util.Scanner;
import java.io.*;

public class Main {
    public static void main(String[] args) {{
        Scanner scanner = new Scanner(System.in);
        File file = new File("info.txt");

        bankAccount acc = new bankAccount("1234-1234-1234-1234","1234",12);
        ATM atm = new ATM(3455);
        Client client = new Client(1345);
        boolean match = false;

        while (!match) {
            System.out.println("Введите номер карты (формат xxxx-xxxx-xxxx-xxxx):");
            String cardNumber = scanner.nextLine();

            if (bankAccount.isValidCardNumber(cardNumber) && (Objects.equals(cardNumber, acc.getNumberOfCard()))) {
                System.out.println("Номер введен верно.");
                match = true;
            }
            else if (bankAccount.isValidCardNumber(cardNumber) && (!Objects.equals(cardNumber, acc.getNumberOfCard()))){
                System.out.println("Неверный номер карты. Пожалуйста, попробуйте еще раз.");
            }
             else {
                System.out.println("Неверный формат номера карты. Пожалуйста, попробуйте еще раз.");
            }
        }
        match = false;

        while (!match){
            System.out.println("Введите пин-код карты:");
            String cardPinCode = scanner.nextLine();

            if (bankAccount.isValidCardPin(cardPinCode) && Objects.equals(cardPinCode,acc.getPinCode())) {
                System.out.println("Пин карты введен верно.");
                match = true;
            }
            else if(bankAccount.isValidCardPin(cardPinCode) && !Objects.equals(cardPinCode,acc.getPinCode())) {
                System.out.println("Пин карты введен неверно. Пожалуйста, попробуйте еще раз.");
            }

            else {
                System.out.println("Неверный формат пин-кода карты или неверный пин. Пожалуйста, попробуйте еще раз.");
            }

        }


        while (true) {
            System.out.println(
                    "Выберете пункт меню:\n" +
                            "0. выход\n" +
                            "1. Проверить баланс\n" +
                            "2. Пополнить баланс\n" +
                            "3. Cнять деньги\n"

            );
            int choice = scanner.nextInt();
            if (choice == 0)
                break;
            switch (choice) {
                case 1:
                    System.out.println(acc.getBalance());
                    break;
                case 2:
                    atm.upBalance(acc,client);
                    break;
                case 3:
                    atm.lowBalance(acc,client);
                default:
                    System.out.println("выбран неправильный пункт меню, повторите ввод.");
            }
        }




        }
    }
}