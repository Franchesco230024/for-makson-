package task;
import java.util.regex.Pattern;
import java.util.Scanner;
public class bankAccount {

    private String numberOfCard;
    private String pinCode;
    private float balance;

    public bankAccount(String numberOfCard, String pinCode, float balance){
        this.numberOfCard = numberOfCard;
        this.pinCode = pinCode;
        this.balance = balance;
    }
    public void setNumberOfCard(String numberOfCard){this.numberOfCard = numberOfCard;}
    public void setPinCode(String pinCode){this.pinCode= pinCode;}
    public void setBalance(float balance){this.balance= balance;}
    public float getBalance() {return balance;}
    public String getPinCode() {return pinCode;}
    public String getNumberOfCard() {return numberOfCard;}

    public String toString(){
        String info =  numberOfCard + pinCode + balance;
        return info;
    }

    public static boolean isValidCardNumber(String cardNumber) {
        String regex = "\\d{4}-\\d{4}-\\d{4}-\\d{4}";
        return Pattern.matches(regex, cardNumber);
    }
    public static boolean isValidCardPin(String cardPinCode) {
        String regex = "\\d{4}";
        return Pattern.matches(regex, cardPinCode);
    }
}


